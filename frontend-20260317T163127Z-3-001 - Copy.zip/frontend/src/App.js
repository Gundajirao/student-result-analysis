import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import Subjects from './pages/Subjects';
import Upload from './pages/Upload';
import Analysis from './pages/Analysis';
import Arrears from './pages/Arrears';
import Charts from './pages/Charts';
import Reports from './pages/Reports';

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('dashboard');

  useEffect(() => {
    const s = localStorage.getItem('user');
    const t = localStorage.getItem('token');
    if (s && t) { try { setUser(JSON.parse(s)); } catch { localStorage.clear(); } }
  }, []);

  if (!user) return <Login onLogin={(u) => { setUser(u); setPage('dashboard'); }} />;

  const pages = { dashboard: Dashboard, students: Students, subjects: Subjects, upload: Upload, analysis: Analysis, arrears: Arrears, charts: Charts, reports: Reports };
  const Page = pages[page] || Dashboard;

  return (
    <div className="app-layout">
      <Sidebar active={page} onNavigate={setPage} user={user} onLogout={() => { localStorage.clear(); setUser(null); }} />
      <main className="main-content"><Page /></main>
    </div>
  );
}
