const db = require('../config/db');

exports.getDashboardStats = async (req, res) => {
  try {
    const [[{ts}]] = await db.query('SELECT COUNT(*) AS ts FROM students');
    const [[{tsub}]] = await db.query('SELECT COUNT(*) AS tsub FROM subjects');
    const [[{tr}]] = await db.query('SELECT COUNT(*) AS tr FROM results');
    const [[{td}]] = await db.query('SELECT COUNT(*) AS td FROM departments');
    const [[{tp}]] = await db.query('SELECT COUNT(*) AS tp FROM results r JOIN subjects sub ON r.subject_id = sub.id WHERE r.marks_obtained >= sub.pass_mark');
    const tf = tr - tp;
    const pr = tr > 0 ? ((tp / tr) * 100).toFixed(2) : 0;
    const [[{sa}]] = await db.query('SELECT COUNT(DISTINCT r.student_id) AS sa FROM results r JOIN subjects sub ON r.subject_id = sub.id WHERE r.marks_obtained < sub.pass_mark');
    res.json({ success: true, data: { totalStudents: ts, totalSubjects: tsub, totalResults: tr, totalDepartments: td, totalPassed: tp, totalFailed: tf, passRate: Number(pr), studentsWithArrears: sa, totalArrearEntries: tf } });
  } catch (error) { console.error(error); res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getSubjectWise = async (req, res) => {
  try {
    const { department_id, semester_id } = req.query;
    let q = `SELECT sub.id, sub.code, sub.name, sub.pass_mark, d.code AS department_code, sem.semester_number,
             COUNT(r.id) AS total_appeared,
             SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END) AS total_passed,
             SUM(CASE WHEN r.marks_obtained < sub.pass_mark THEN 1 ELSE 0 END) AS total_failed,
             ROUND(AVG(r.marks_obtained),2) AS avg_marks, MAX(r.marks_obtained) AS highest_marks, MIN(r.marks_obtained) AS lowest_marks,
             ROUND(SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END)*100.0/COUNT(r.id),2) AS pass_percentage
             FROM subjects sub JOIN results r ON sub.id = r.subject_id JOIN departments d ON sub.department_id = d.id JOIN semesters sem ON sub.semester_id = sem.id WHERE 1=1`;
    const p = [];
    if (department_id) { q += ' AND sub.department_id = ?'; p.push(department_id); }
    if (semester_id) { q += ' AND sub.semester_id = ?'; p.push(semester_id); }
    q += ' GROUP BY sub.id ORDER BY total_failed DESC';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getStudentArrears = async (req, res) => {
  try {
    const { department_id } = req.query;
    let q = `SELECT s.id, s.roll_no, s.name, s.year, d.name AS department_name, d.code AS department_code,
             COUNT(r.id) AS arrear_count,
             GROUP_CONCAT(DISTINCT sub.code ORDER BY sub.code SEPARATOR ', ') AS arrear_subjects
             FROM students s JOIN results r ON s.id = r.student_id JOIN subjects sub ON r.subject_id = sub.id
             JOIN departments d ON s.department_id = d.id WHERE r.marks_obtained < sub.pass_mark`;
    const p = [];
    if (department_id) { q += ' AND s.department_id = ?'; p.push(department_id); }
    q += ' GROUP BY s.id ORDER BY arrear_count DESC';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getStudentArrearDetails = async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT r.*, s.roll_no, s.name AS student_name, sub.code AS subject_code, sub.name AS subject_name, sub.pass_mark,
      (sub.pass_mark - r.marks_obtained) AS deficit, sem.semester_number, d.code AS department_code
      FROM results r JOIN students s ON r.student_id = s.id JOIN subjects sub ON r.subject_id = sub.id
      JOIN semesters sem ON r.semester_id = sem.id JOIN departments d ON s.department_id = d.id
      WHERE r.student_id = ? AND r.marks_obtained < sub.pass_mark ORDER BY sem.semester_number, sub.code`, [req.params.studentId]);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getDeptPerformance = async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT d.id, d.name, d.code, COUNT(DISTINCT s.id) AS total_students, COUNT(r.id) AS total_results,
      SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END) AS total_passed,
      SUM(CASE WHEN r.marks_obtained < sub.pass_mark THEN 1 ELSE 0 END) AS total_failed,
      ROUND(AVG(r.marks_obtained),2) AS avg_marks,
      ROUND(SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END)*100.0/COUNT(r.id),2) AS pass_percentage
      FROM departments d LEFT JOIN students s ON d.id = s.department_id LEFT JOIN results r ON s.id = r.student_id
      LEFT JOIN subjects sub ON r.subject_id = sub.id WHERE r.id IS NOT NULL GROUP BY d.id ORDER BY pass_percentage DESC`);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getSemPerformance = async (req, res) => {
  try {
    const { department_id } = req.query;
    let q = `SELECT sem.id, sem.name, sem.semester_number, COUNT(r.id) AS total_results,
      SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END) AS total_passed,
      SUM(CASE WHEN r.marks_obtained < sub.pass_mark THEN 1 ELSE 0 END) AS total_failed,
      ROUND(AVG(r.marks_obtained),2) AS avg_marks,
      ROUND(SUM(CASE WHEN r.marks_obtained >= sub.pass_mark THEN 1 ELSE 0 END)*100.0/COUNT(r.id),2) AS pass_percentage
      FROM semesters sem JOIN results r ON sem.id = r.semester_id JOIN subjects sub ON r.subject_id = sub.id`;
    const p = [];
    if (department_id) { q += ' JOIN students s ON r.student_id = s.id WHERE s.department_id = ?'; p.push(department_id); }
    q += ' GROUP BY sem.id ORDER BY sem.semester_number';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getMarksDistribution = async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT
      SUM(CASE WHEN marks_obtained BETWEEN 0 AND 20 THEN 1 ELSE 0 END) AS r1,
      SUM(CASE WHEN marks_obtained BETWEEN 21 AND 40 THEN 1 ELSE 0 END) AS r2,
      SUM(CASE WHEN marks_obtained BETWEEN 41 AND 60 THEN 1 ELSE 0 END) AS r3,
      SUM(CASE WHEN marks_obtained BETWEEN 61 AND 80 THEN 1 ELSE 0 END) AS r4,
      SUM(CASE WHEN marks_obtained BETWEEN 81 AND 100 THEN 1 ELSE 0 END) AS r5 FROM results`);
    res.json({ success: true, data: [
      { range: '0-20', count: rows[0].r1 }, { range: '21-40', count: rows[0].r2 },
      { range: '41-60', count: rows[0].r3 }, { range: '61-80', count: rows[0].r4 }, { range: '81-100', count: rows[0].r5 }
    ]});
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getArrearDistribution = async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT arrear_count, COUNT(*) AS student_count FROM (
      SELECT s.id, COUNT(r.id) AS arrear_count FROM students s JOIN results r ON s.id = r.student_id
      JOIN subjects sub ON r.subject_id = sub.id WHERE r.marks_obtained < sub.pass_mark GROUP BY s.id
    ) AS ac GROUP BY arrear_count ORDER BY arrear_count`);
    res.json({ success: true, data: rows });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getDepartments = async (req, res) => {
  try { const [rows] = await db.query('SELECT * FROM departments ORDER BY name'); res.json({ success: true, data: rows }); }
  catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getSemesters = async (req, res) => {
  try { const [rows] = await db.query('SELECT * FROM semesters ORDER BY semester_number'); res.json({ success: true, data: rows }); }
  catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};
