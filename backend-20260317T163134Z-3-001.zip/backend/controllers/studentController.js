const db = require('../config/db');

exports.getAll = async (req, res) => {
  try {
    const { department_id, year, search } = req.query;
    let q = 'SELECT s.*, d.name AS department_name, d.code AS department_code FROM students s JOIN departments d ON s.department_id = d.id WHERE 1=1';
    const p = [];
    if (department_id) { q += ' AND s.department_id = ?'; p.push(department_id); }
    if (year) { q += ' AND s.year = ?'; p.push(year); }
    if (search) { q += ' AND (s.name LIKE ? OR s.roll_no LIKE ?)'; p.push(`%${search}%`, `%${search}%`); }
    q += ' ORDER BY s.roll_no ASC';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows, total: rows.length });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getById = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT s.*, d.name AS department_name, d.code AS department_code FROM students s JOIN departments d ON s.department_id = d.id WHERE s.id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Student not found' });
    res.json({ success: true, data: rows[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.create = async (req, res) => {
  try {
    const { roll_no, name, email, phone, department_id, year, batch } = req.body;
    if (!roll_no || !name || !department_id) return res.status(400).json({ success: false, message: 'Roll number, name, department required' });
    const [existing] = await db.query('SELECT id FROM students WHERE roll_no = ?', [roll_no]);
    if (existing.length > 0) return res.status(409).json({ success: false, message: 'Roll number already exists' });
    const [result] = await db.query('INSERT INTO students (roll_no, name, email, phone, department_id, year, batch) VALUES (?,?,?,?,?,?,?)',
      [roll_no, name, email || null, phone || null, department_id, year || 1, batch || null]);
    const [newRow] = await db.query('SELECT s.*, d.name AS department_name, d.code AS department_code FROM students s JOIN departments d ON s.department_id = d.id WHERE s.id = ?', [result.insertId]);
    res.status(201).json({ success: true, message: 'Student created', data: newRow[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.update = async (req, res) => {
  try {
    const { roll_no, name, email, phone, department_id, year, batch } = req.body;
    await db.query('UPDATE students SET roll_no=?, name=?, email=?, phone=?, department_id=?, year=?, batch=? WHERE id=?',
      [roll_no, name, email, phone, department_id, year, batch, req.params.id]);
    const [updated] = await db.query('SELECT s.*, d.name AS department_name, d.code AS department_code FROM students s JOIN departments d ON s.department_id = d.id WHERE s.id = ?', [req.params.id]);
    res.json({ success: true, message: 'Student updated', data: updated[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.delete = async (req, res) => {
  try {
    await db.query('DELETE FROM students WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Student deleted' });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};
