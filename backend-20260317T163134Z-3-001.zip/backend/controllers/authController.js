const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ success: false, message: 'Username and password required' });

    const [rows] = await db.query('SELECT * FROM admins WHERE username = ?', [username]);
    if (rows.length === 0) return res.status(401).json({ success: false, message: 'Invalid credentials' });

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ success: false, message: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role, fullName: user.full_name },
      process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    res.json({
      success: true, message: 'Login successful',
      data: { token, user: { id: user.id, username: user.username, fullName: user.full_name, email: user.email, role: user.role } }
    });
  } catch (error) { console.error('Login error:', error); res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.register = async (req, res) => {
  try {
    const { username, password, fullName, email, role } = req.body;
    if (!username || !password || !fullName) return res.status(400).json({ success: false, message: 'Required fields missing' });

    const [existing] = await db.query('SELECT id FROM admins WHERE username = ?', [username]);
    if (existing.length > 0) return res.status(409).json({ success: false, message: 'Username already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await db.query('INSERT INTO admins (username, password, full_name, email, role) VALUES (?,?,?,?,?)',
      [username, hashedPassword, fullName, email || null, role || 'faculty']);

    res.status(201).json({ success: true, message: 'User registered', data: { id: result.insertId } });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getProfile = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, username, full_name, email, role FROM admins WHERE id = ?', [req.user.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({ success: true, data: rows[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};
