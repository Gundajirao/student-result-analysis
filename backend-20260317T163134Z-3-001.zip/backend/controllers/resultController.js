const db = require('../config/db');
const XLSX = require('xlsx');

exports.getAll = async (req, res) => {
  try {
    const { student_id, subject_id, semester_id, department_id } = req.query;
    let q = `SELECT r.*, s.roll_no, s.name AS student_name, sub.code AS subject_code, sub.name AS subject_name, sub.pass_mark,
             d.name AS department_name, d.code AS department_code, sem.name AS semester_name, sem.semester_number,
             CASE WHEN r.marks_obtained >= sub.pass_mark THEN 'pass' ELSE 'fail' END AS status
             FROM results r JOIN students s ON r.student_id = s.id JOIN subjects sub ON r.subject_id = sub.id
             JOIN departments d ON s.department_id = d.id JOIN semesters sem ON r.semester_id = sem.id WHERE 1=1`;
    const p = [];
    if (student_id) { q += ' AND r.student_id = ?'; p.push(student_id); }
    if (subject_id) { q += ' AND r.subject_id = ?'; p.push(subject_id); }
    if (semester_id) { q += ' AND r.semester_id = ?'; p.push(semester_id); }
    if (department_id) { q += ' AND s.department_id = ?'; p.push(department_id); }
    q += ' ORDER BY s.roll_no, sub.code';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows, total: rows.length });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.create = async (req, res) => {
  try {
    const { student_id, subject_id, marks_obtained, exam_type, exam_date } = req.body;
    if (!student_id || !subject_id || marks_obtained === undefined) return res.status(400).json({ success: false, message: 'Student, subject, marks required' });
    const [subRows] = await db.query('SELECT semester_id FROM subjects WHERE id = ?', [subject_id]);
    if (subRows.length === 0) return res.status(404).json({ success: false, message: 'Subject not found' });
    const [result] = await db.query('INSERT INTO results (student_id,subject_id,semester_id,marks_obtained,exam_type,exam_date) VALUES (?,?,?,?,?,?)',
      [student_id, subject_id, subRows[0].semester_id, marks_obtained, exam_type || 'regular', exam_date || new Date()]);
    res.status(201).json({ success: true, message: 'Result added', data: { id: result.insertId } });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ success: false, message: 'Result already exists for this student-subject combination' });
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

exports.uploadCSV = async (req, res) => {
  try {
    const { csvData } = req.body;
    if (!csvData) return res.status(400).json({ success: false, message: 'CSV data required' });
    const lines = csvData.trim().split('\n').slice(1);
    let ok = 0, fail = 0;
    for (const line of lines) {
      const [rollNo, subCode, marks] = line.split(',').map(s => s.trim());
      try {
        const [stu] = await db.query('SELECT id FROM students WHERE roll_no = ?', [rollNo]);
        const [sub] = await db.query('SELECT id, semester_id FROM subjects WHERE code = ?', [subCode]);
        if (stu.length === 0 || sub.length === 0 || isNaN(Number(marks))) { fail++; continue; }
        await db.query('INSERT INTO results (student_id,subject_id,semester_id,marks_obtained,exam_type,exam_date) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained)',
          [stu[0].id, sub[0].id, sub[0].semester_id, Number(marks), 'regular', new Date()]);
        ok++;
      } catch (e) { fail++; }
    }
    res.json({ success: true, message: `Uploaded ${ok} results, ${fail} errors` });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.uploadExcel = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'Excel file required' });
    const workbook = XLSX.readFile(req.file.path);
    const data = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
    let ok = 0, fail = 0;
    for (const row of data) {
      const rollNo = row['RollNo'] || row['roll_no'];
      const subCode = row['SubjectCode'] || row['subject_code'];
      const marks = row['Marks'] || row['marks'];
      if (!rollNo || !subCode || marks === undefined) { fail++; continue; }
      try {
        const [stu] = await db.query('SELECT id FROM students WHERE roll_no = ?', [rollNo]);
        const [sub] = await db.query('SELECT id, semester_id FROM subjects WHERE code = ?', [subCode]);
        if (stu.length === 0 || sub.length === 0) { fail++; continue; }
        await db.query('INSERT INTO results (student_id,subject_id,semester_id,marks_obtained,exam_type,exam_date) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained)',
          [stu[0].id, sub[0].id, sub[0].semester_id, Number(marks), 'regular', new Date()]);
        ok++;
      } catch (e) { fail++; }
    }
    res.json({ success: true, message: `Processed ${ok} results, ${fail} errors` });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.update = async (req, res) => {
  try {
    const { marks_obtained } = req.body;
    await db.query('UPDATE results SET marks_obtained = ? WHERE id = ?', [marks_obtained, req.params.id]);
    res.json({ success: true, message: 'Result updated' });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.delete = async (req, res) => {
  try {
    await db.query('DELETE FROM results WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Result deleted' });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};
