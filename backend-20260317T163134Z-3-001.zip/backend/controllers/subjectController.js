const db = require('../config/db');

exports.getAll = async (req, res) => {
  try {
    const { department_id, semester_id } = req.query;
    let q = 'SELECT sub.*, d.name AS department_name, d.code AS department_code, sem.name AS semester_name, sem.semester_number FROM subjects sub JOIN departments d ON sub.department_id = d.id JOIN semesters sem ON sub.semester_id = sem.id WHERE 1=1';
    const p = [];
    if (department_id) { q += ' AND sub.department_id = ?'; p.push(department_id); }
    if (semester_id) { q += ' AND sub.semester_id = ?'; p.push(semester_id); }
    q += ' ORDER BY sub.department_id, sub.semester_id, sub.code';
    const [rows] = await db.query(q, p);
    res.json({ success: true, data: rows, total: rows.length });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.getById = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT sub.*, d.name AS department_name, d.code AS department_code, sem.name AS semester_name, sem.semester_number FROM subjects sub JOIN departments d ON sub.department_id = d.id JOIN semesters sem ON sub.semester_id = sem.id WHERE sub.id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ success: false, message: 'Subject not found' });
    res.json({ success: true, data: rows[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.create = async (req, res) => {
  try {
    const { code, name, department_id, semester_id, credits, pass_mark, max_marks } = req.body;
    if (!code || !name || !department_id || !semester_id) return res.status(400).json({ success: false, message: 'Required fields missing' });
    const [existing] = await db.query('SELECT id FROM subjects WHERE code = ?', [code]);
    if (existing.length > 0) return res.status(409).json({ success: false, message: 'Subject code already exists' });
    const [result] = await db.query('INSERT INTO subjects (code,name,department_id,semester_id,credits,pass_mark,max_marks) VALUES (?,?,?,?,?,?,?)',
      [code, name, department_id, semester_id, credits || 3, pass_mark || 40, max_marks || 100]);
    const [newRow] = await db.query('SELECT sub.*, d.name AS department_name, d.code AS department_code, sem.name AS semester_name, sem.semester_number FROM subjects sub JOIN departments d ON sub.department_id = d.id JOIN semesters sem ON sub.semester_id = sem.id WHERE sub.id = ?', [result.insertId]);
    res.status(201).json({ success: true, message: 'Subject created', data: newRow[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.update = async (req, res) => {
  try {
    const { code, name, department_id, semester_id, credits, pass_mark, max_marks } = req.body;
    await db.query('UPDATE subjects SET code=?,name=?,department_id=?,semester_id=?,credits=?,pass_mark=?,max_marks=? WHERE id=?',
      [code, name, department_id, semester_id, credits, pass_mark, max_marks, req.params.id]);
    const [updated] = await db.query('SELECT sub.*, d.name AS department_name, d.code AS department_code, sem.name AS semester_name FROM subjects sub JOIN departments d ON sub.department_id = d.id JOIN semesters sem ON sub.semester_id = sem.id WHERE sub.id = ?', [req.params.id]);
    res.json({ success: true, message: 'Subject updated', data: updated[0] });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};

exports.delete = async (req, res) => {
  try {
    await db.query('DELETE FROM subjects WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Subject deleted' });
  } catch (error) { res.status(500).json({ success: false, message: 'Server error' }); }
};
