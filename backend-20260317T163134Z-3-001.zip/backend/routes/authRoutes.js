const express = require('express');
const router = express.Router();
const c = require('../controllers/authController');
const auth = require('../middleware/auth');
router.post('/login', c.login);
router.post('/register', c.register);
router.get('/profile', auth, c.getProfile);
module.exports = router;
