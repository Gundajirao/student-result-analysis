const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const c = require('../controllers/resultController');
const auth = require('../middleware/auth');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, `results_${Date.now()}${path.extname(file.originalname)}`)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

router.get('/', auth, c.getAll);
router.post('/', auth, c.create);
router.post('/upload-csv', auth, c.uploadCSV);
router.post('/upload-excel', auth, upload.single('file'), c.uploadExcel);
router.put('/:id', auth, c.update);
router.delete('/:id', auth, c.delete);
module.exports = router;
