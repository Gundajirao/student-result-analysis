const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function seed() {
  console.log('🌱 Starting database seeding...\n');
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '', multipleStatements: true
  });

  await conn.query('CREATE DATABASE IF NOT EXISTS result_analysis');
  await conn.query('USE result_analysis');
  console.log('✅ Connected to MySQL');

  // Create tables
  await conn.query(`CREATE TABLE IF NOT EXISTS departments (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, code VARCHAR(10) NOT NULL UNIQUE, hod_name VARCHAR(100), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await conn.query(`CREATE TABLE IF NOT EXISTS semesters (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, semester_number INT NOT NULL UNIQUE)`);
  await conn.query(`CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL, email VARCHAR(100), role ENUM('admin','faculty') DEFAULT 'admin', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await conn.query(`CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, roll_no VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, email VARCHAR(100), phone VARCHAR(15), department_id INT NOT NULL, year INT NOT NULL DEFAULT 1, batch VARCHAR(20), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE)`);
  await conn.query(`CREATE TABLE IF NOT EXISTS subjects (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(20) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, department_id INT NOT NULL, semester_id INT NOT NULL, credits INT DEFAULT 3, pass_mark INT NOT NULL DEFAULT 40, max_marks INT NOT NULL DEFAULT 100, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE, FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE)`);
  await conn.query(`CREATE TABLE IF NOT EXISTS results (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, subject_id INT NOT NULL, semester_id INT NOT NULL, marks_obtained INT NOT NULL, exam_type ENUM('regular','supplementary','improvement') DEFAULT 'regular', exam_date DATE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE, FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE, FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE CASCADE, UNIQUE KEY unique_result (student_id, subject_id, exam_type))`);

  console.log('📋 Creating tables...');

  // Clear data
  await conn.query('SET FOREIGN_KEY_CHECKS = 0');
  await conn.query('TRUNCATE TABLE results'); await conn.query('TRUNCATE TABLE subjects');
  await conn.query('TRUNCATE TABLE students'); await conn.query('TRUNCATE TABLE admins');
  await conn.query('TRUNCATE TABLE semesters'); await conn.query('TRUNCATE TABLE departments');
  await conn.query('SET FOREIGN_KEY_CHECKS = 1');

  // Seed departments
  await conn.query(`INSERT INTO departments (name, code, hod_name) VALUES ('Computer Science','CS','Dr. Ramesh Kumar'),('Electronics & Communication','ECE','Dr. Priya Sharma'),('Mechanical Engineering','MECH','Dr. Suresh Babu'),('Civil Engineering','CIVIL','Dr. Lakshmi Devi')`);

  // Seed semesters
  await conn.query(`INSERT INTO semesters (name, semester_number) VALUES ('Semester 1',1),('Semester 2',2),('Semester 3',3),('Semester 4',4),('Semester 5',5),('Semester 6',6),('Semester 7',7),('Semester 8',8)`);

  // Seed admin
  const pw = await bcrypt.hash('admin123', 10);
  await conn.query('INSERT INTO admins (username,password,full_name,email,role) VALUES (?,?,?,?,?)', ['admin', pw, 'System Administrator', 'admin@college.edu', 'admin']);

  console.log('🌱 Seeding results...');

  // Seed subjects
  const subjects = [
    ['CS301','Data Structures & Algorithms',1,3,4,40],['CS302','Database Management Systems',1,3,4,40],
    ['CS303','Object Oriented Programming',1,3,3,40],['CS304','Discrete Mathematics',1,3,3,40],
    ['CS401','Operating Systems',1,4,4,40],['CS402','Computer Networks',1,4,4,40],['CS403','Software Engineering',1,4,3,40],
    ['CS501','Machine Learning',1,5,4,40],['CS502','Web Technologies',1,5,3,40],
    ['EC301','Circuit Theory',2,3,4,40],['EC302','Signal Processing',2,3,4,40],['EC303','Analog Electronics',2,3,3,40],
    ['EC401','VLSI Design',2,4,4,40],['EC402','Communication Systems',2,4,4,40],
    ['ME301','Thermodynamics',3,3,4,40],['ME302','Fluid Mechanics',3,3,4,40],['ME303','Strength of Materials',3,3,3,40],
    ['ME401','Heat Transfer',3,4,4,40],
    ['CE301','Structural Analysis',4,3,4,40],['CE302','Surveying',4,3,4,40],['CE303','Geotechnical Engineering',4,3,3,40],
    ['CE401','Concrete Technology',4,4,4,40],
  ];
  for (const s of subjects) await conn.query('INSERT INTO subjects (code,name,department_id,semester_id,credits,pass_mark) VALUES (?,?,?,?,?,?)', s);

  // Seed students
  const students = [
    ['CS2021001','Aarav Sharma','aarav@college.edu',1,3],['CS2021002','Priya Patel','priya@college.edu',1,3],
    ['CS2021003','Rahul Kumar','rahul@college.edu',1,3],['CS2021004','Sneha Reddy','sneha@college.edu',1,3],
    ['CS2021005','Vikram Singh','vikram@college.edu',1,3],['CS2021006','Ananya Iyer','ananya@college.edu',1,3],
    ['CS2021007','Karthik Nair','karthik@college.edu',1,3],['CS2021008','Divya Menon','divya@college.edu',1,3],
    ['CS2021009','Arjun Prasad','arjunp@college.edu',1,3],['CS2021010','Megha Krishnan','megha@college.edu',1,3],
    ['EC2021001','Arjun Das','arjund@college.edu',2,3],['EC2021002','Meera Joshi','meera@college.edu',2,3],
    ['EC2021003','Rohan Gupta','rohan@college.edu',2,3],['EC2021004','Lakshmi Pillai','lakshmi@college.edu',2,3],
    ['EC2021005','Sanjay Verma','sanjay@college.edu',2,3],['EC2021006','Nithya Raman','nithya@college.edu',2,3],
    ['ME2021001','Suresh Kumar','suresh@college.edu',3,3],['ME2021002','Kavitha Rao','kavitha@college.edu',3,3],
    ['ME2021003','Aditya Verma','aditya@college.edu',3,3],['ME2021004','Deepa Nanda','deepa@college.edu',3,3],
    ['ME2021005','Manoj Tiwari','manoj@college.edu',3,3],
    ['CE2021001','Pooja Nanda','pooja@college.edu',4,3],['CE2021002','Nikhil Shetty','nikhil@college.edu',4,3],
    ['CE2021003','Revathi Krishnan','revathi@college.edu',4,3],['CE2021004','Vishal Patil','vishal@college.edu',4,3],
  ];
  for (const s of students) await conn.query('INSERT INTO students (roll_no,name,email,department_id,year) VALUES (?,?,?,?,?)', s);

  // Seed results
  const results = [
    [1,1,3,78],[2,1,3,85],[3,1,3,32],[4,1,3,91],[5,1,3,28],[6,1,3,67],[7,1,3,55],[8,1,3,38],[9,1,3,72],[10,1,3,45],
    [1,2,3,65],[2,2,3,72],[3,2,3,48],[4,2,3,88],[5,2,3,35],[6,2,3,56],[7,2,3,41],[8,2,3,29],[9,2,3,82],[10,2,3,60],
    [1,3,3,82],[2,3,3,90],[3,3,3,55],[4,3,3,76],[5,3,3,22],[6,3,3,68],[7,3,3,37],[8,3,3,52],[9,3,3,44],[10,3,3,71],
    [1,4,3,58],[2,4,3,76],[3,4,3,30],[4,4,3,85],[5,4,3,18],[6,4,3,62],[7,4,3,45],[8,4,3,33],[9,4,3,55],[10,4,3,40],
    [1,5,4,70],[2,5,4,80],[3,5,4,36],[4,5,4,74],[5,5,4,42],[6,5,4,58],[7,5,4,63],[8,5,4,25],[9,5,4,81],[10,5,4,47],
    [1,6,4,62],[2,6,4,88],[3,6,4,39],[4,6,4,95],[5,6,4,31],[6,6,4,53],[7,6,4,48],[8,6,4,37],[9,6,4,76],[10,6,4,56],
    [1,7,4,75],[2,7,4,82],[3,7,4,44],[4,7,4,68],[5,7,4,26],[6,7,4,71],[7,7,4,52],[8,7,4,40],[9,7,4,88],[10,7,4,61],
    [11,10,3,72],[12,10,3,58],[13,10,3,35],[14,10,3,81],[15,10,3,44],[16,10,3,27],
    [11,11,3,65],[12,11,3,42],[13,11,3,38],[14,11,3,75],[15,11,3,55],[16,11,3,30],
    [11,12,3,80],[12,12,3,66],[13,12,3,28],[14,12,3,92],[15,12,3,50],[16,12,3,36],
    [11,13,4,68],[12,13,4,45],[13,13,4,32],[14,13,4,77],[15,13,4,51],[16,13,4,40],
    [11,14,4,73],[12,14,4,55],[13,14,4,29],[14,14,4,86],[15,14,4,48],[16,14,4,33],
    [17,15,3,68],[18,15,3,55],[19,15,3,33],[20,15,3,78],[21,15,3,42],
    [17,16,3,45],[18,16,3,62],[19,16,3,29],[20,16,3,71],[21,16,3,38],
    [17,17,3,74],[18,17,3,48],[19,17,3,36],[20,17,3,82],[21,17,3,57],
    [17,18,4,60],[18,18,4,43],[19,18,4,31],[20,18,4,75],[21,18,4,52],
    [22,19,3,76],[23,19,3,34],[24,19,3,61],[25,19,3,85],
    [22,20,3,58],[23,20,3,42],[24,20,3,37],[25,20,3,90],
    [22,21,3,82],[23,21,3,28],[24,21,3,54],[25,21,3,67],
    [22,22,4,70],[23,22,4,35],[24,22,4,48],[25,22,4,78],
  ];
  for (const r of results) await conn.query('INSERT INTO results (student_id,subject_id,semester_id,marks_obtained,exam_type,exam_date) VALUES (?,?,?,?,?,?)', [r[0],r[1],r[2],r[3],'regular','2024-05-15']);

  // Stats
  const [[{sc}]] = await conn.query('SELECT COUNT(*) AS sc FROM students');
  const [[{subc}]] = await conn.query('SELECT COUNT(*) AS subc FROM subjects');
  const [[{rc}]] = await conn.query('SELECT COUNT(*) AS rc FROM results');
  const [[{fc}]] = await conn.query('SELECT COUNT(*) AS fc FROM results r JOIN subjects sub ON r.subject_id = sub.id WHERE r.marks_obtained < sub.pass_mark');

  console.log(`\n✅ Seeding complete!`);
  console.log(`  ${sc} students | ${subc} subjects | ${rc} results | ${fc} arrears`);
  console.log(`\n🔑 Login: admin / admin123\n`);

  await conn.end();
  process.exit(0);
}
seed().catch(err => { console.error('❌ Seed error:', err); process.exit(1); });
